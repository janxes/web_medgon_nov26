import React, { useEffect, useState } from 'react';
import { ArrowRight, Calendar, ExternalLink, FileText } from 'lucide-react';
import { getAssetUrl } from '../utils/assetUrl';

export interface WordPressPost {
  id: number | string;
  date?: string;
  link: string;
  title: {
    rendered: string;
  };
  excerpt: {
    rendered: string;
  };
  _embedded?: {
    'wp:featuredmedia'?: {
      '0'?: {
        source_url?: string;
        alt_text?: string;
      };
      [key: number]: {
        source_url?: string;
        alt_text?: string;
      };
    };
  };
}

interface BlogPostsProps {
  onNavigate?: (view: string, modelId?: string) => void;
  limit?: number;
}

// URL exacta del servidor WordPress de pruebas en CDMON
export const WP_BASE_URL = 'http://www.medmedpru.com.mialias.net/';

const FALLBACK_POSTS: WordPressPost[] = [
  {
    id: 'epbd-2030',
    date: '2026-05-15T09:00:00',
    link: 'http://www.medmedpru.com.mialias.net/',
    title: {
      rendered:
        'Por qué tu vivienda convencional quedará obsoleta ante la Directiva Europea EPBD 2028-2030',
    },
    excerpt: {
      rendered:
        '<p>La Unión Europea ha ratificado la prohibición de emisiones directas y la obligatoriedad de analizar el ciclo de vida completo en nuevas construcciones. Explicamos cómo la madera técnica Passivhaus supera con creces estas exigencias.</p>',
    },
    _embedded: {
      'wp:featuredmedia': {
        '0': {
          source_url: getAssetUrl('MG105/industrial_luminous_house_exterior.jpg'),
        },
      },
    },
  },
  {
    id: 'blower-door',
    date: '2026-04-28T09:00:00',
    link: 'http://www.medmedpru.com.mialias.net/',
    title: {
      rendered:
        'El Test Blower Door n50: la prueba empírica que ninguna obra tradicional se atreve a pasar',
    },
    excerpt: {
      rendered:
        '<p>El ensayo de presurización Blower Door mide las renovaciones de aire indeseadas a través de la envolvente. En Medgón garantizamos n50 ≤ 0.6 ren/h gracias al sellado de fábrica en Carrión de los Condes.</p>',
    },
    _embedded: {
      'wp:featuredmedia': {
        '0': {
          source_url: getAssetUrl('MG128/boho_autumn_exterior.jpg'),
        },
      },
    },
  },
  {
    id: 'vmc-zehnder',
    date: '2026-04-10T09:00:00',
    link: 'http://www.medmedpru.com.mialias.net/',
    title: {
      rendered:
        'VMC de doble flujo Zehnder: cómo respirar aire 100% puro sin abrir ventanas ni perder calor',
    },
    excerpt: {
      rendered:
        '<p>La ventilación mecánica controlada con recuperación entálpica renueva el 100% del volumen de aire cada 2 horas, filtrando pólenes, ácaros y reduciendo los niveles de CO2 por debajo de 800 ppm para un descanso reparador.</p>',
    },
    _embedded: {
      'wp:featuredmedia': {
        '0': {
          source_url: getAssetUrl('MG148/l_shaped_farmhouse_golden_hour.jpg'),
        },
      },
    },
  },
  {
    id: 'madera-tecnica-cnc',
    date: '2026-03-22T09:00:00',
    link: 'http://www.medmedpru.com.mialias.net/',
    title: {
      rendered:
        'Estructura de madera técnica vs hormigón: por qué la construcción industrializada lidera el siglo XXI',
    },
    excerpt: {
      rendered:
        '<p>Comparativa rigurosa de tolerancias milimétricas en taller climatizado frente a las desviaciones de centímetros de la obra tradicional al aire libre. Menos peso, mayor resistencia y cero sorpresas de plazo.</p>',
    },
    _embedded: {
      'wp:featuredmedia': {
        '0': {
          source_url: getAssetUrl('/marratxi-passivhaus.webp'),
        },
      },
    },
  },
];

export const BlogPosts: React.FC<BlogPostsProps> = ({ limit }) => {
  const [posts, setPosts] = useState<WordPressPost[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    let isMounted = true;

    const fetchWordPressPosts = async () => {
      setLoading(true);
      try {
        const response = await fetch(
          'http://www.medmedpru.com.mialias.net/wp-json/wp/v2/posts?_embed'
        );

        if (!response.ok) {
          throw new Error(`Error HTTP: ${response.status}`);
        }

        const data: WordPressPost[] = await response.json();

        if (isMounted) {
          if (Array.isArray(data) && data.length > 0) {
            setPosts(limit ? data.slice(0, limit) : data);
          } else {
            setPosts(limit ? FALLBACK_POSTS.slice(0, limit) : FALLBACK_POSTS);
          }
        }
      } catch {
        // Mantiene el contenido y el SEO protegidos si el entorno bloquea HTTP o sin conexión
        if (isMounted) {
          setPosts(limit ? FALLBACK_POSTS.slice(0, limit) : FALLBACK_POSTS);
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    fetchWordPressPosts();

    return () => {
      isMounted = false;
    };
  }, [limit]);

  const displayedPosts = posts.length > 0 ? posts : FALLBACK_POSTS;

  // Datos estructurados Schema.org Blog para proteger el SEO
  const blogSchema = {
    '@context': 'https://schema.org',
    '@type': 'Blog',
    name: 'Blog Técnico Passivhaus & Normativa · Medgón',
    description:
      'Artículos especializados elaborados por los ingenieros y Passivhaus Designers de Medgón en Carrión de los Condes (Palencia).',
    url: 'http://www.medmedpru.com.mialias.net/',
    blogPost: displayedPosts.map((post) => {
      const featuredImage =
        post._embedded?.['wp:featuredmedia']?.['0']?.source_url || '';
      return {
        '@type': 'BlogPosting',
        headline: post.title.rendered.replace(/<[^>]+>/g, ''),
        url: post.link,
        datePublished: post.date || undefined,
        image: featuredImage || undefined,
      };
    }),
  };

  return (
    <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
      {/* Protección SEO mediante JSON-LD Schema.org */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(blogSchema) }}
      />

      {/* Header */}
      <div className="max-w-3xl space-y-4">
        <div className="text-xs font-bold uppercase tracking-widest text-[#0DA836]">
          Divulgación Técnica & Artículos de Autoridad
        </div>
        <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-[#16181B]">
          Blog Técnico Passivhaus & Normativa
        </h1>
        <p className="text-base sm:text-lg text-[#5A606A] leading-relaxed">
          Artículos especializados elaborados por los ingenieros y Passivhaus Designers de Medgón en Carrión de los Condes (Palencia).
        </p>
      </div>

      {/* Estado de carga esqueleto */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {[1, 2, 3, 4].map((skeleton) => (
            <div
              key={skeleton}
              className="bg-white border border-[#16181B]/10 rounded-lg overflow-hidden p-6 sm:p-8 space-y-4 animate-pulse"
            >
              <div className="h-52 bg-[#FAF8F5] rounded-md w-full" />
              <div className="h-4 bg-[#FAF8F5] rounded w-1/3" />
              <div className="h-6 bg-[#FAF8F5] rounded w-3/4" />
              <div className="h-16 bg-[#FAF8F5] rounded w-full" />
            </div>
          ))}
        </div>
      ) : (
        /* Grid de Artículos conectados a WordPress */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {displayedPosts.map((post) => {
            const titleHtml = post.title.rendered;
            const excerptHtml = post.excerpt.rendered;
            const postLink = post.link;
            const featuredImage =
              post._embedded?.['wp:featuredmedia']?.['0']?.source_url || '';

            const formattedDate = post.date
              ? new Date(post.date).toLocaleDateString('es-ES', {
                  day: 'numeric',
                  month: 'long',
                  year: 'numeric',
                })
              : 'Medgón Editorial';

            return (
              <article
                key={post.id}
                className="bg-white border border-[#16181B]/10 rounded-lg overflow-hidden flex flex-col justify-between hover:border-[#16181B]/30 hover:shadow-sm transition-all group"
              >
                <div>
                  {/* Imagen destacada de WordPress */}
                  {featuredImage ? (
                    <a
                      href={postLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block relative h-56 overflow-hidden bg-[#FAF8F5] border-b border-[#16181B]/10"
                    >
                      <img
                        src={featuredImage}
                        alt={titleHtml.replace(/<[^>]+>/g, '')}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        loading="lazy"
                      />
                    </a>
                  ) : (
                    <div className="h-48 bg-[#FAF8F5] border-b border-[#16181B]/10 flex items-center justify-center text-[#8E95A2]">
                      <FileText className="w-10 h-10 opacity-40" />
                    </div>
                  )}

                  <div className="p-6 sm:p-8 space-y-3">
                    <div className="flex items-center justify-between text-xs text-[#8E95A2]">
                      <span className="font-bold text-[#0DA836] uppercase tracking-wider">
                        Ingeniería Passivhaus
                      </span>
                      <span className="inline-flex items-center gap-1 tabular-nums">
                        <Calendar className="w-3.5 h-3.5" />
                        {formattedDate}
                      </span>
                    </div>

                    {/* Título: post.title.rendered */}
                    <h2 className="text-xl font-bold text-[#16181B] group-hover:text-[#0DA836] transition-colors">
                      <a
                        href={postLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        dangerouslySetInnerHTML={{ __html: titleHtml }}
                      />
                    </h2>

                    {/* Extracto/Resumen: post.excerpt.rendered */}
                    <div
                      className="text-sm text-[#5A606A] leading-relaxed prose prose-sm max-w-none line-clamp-4"
                      dangerouslySetInnerHTML={{ __html: excerptHtml }}
                    />
                  </div>
                </div>

                {/* Enlace original: post.link */}
                <div className="px-6 sm:px-8 pb-6 pt-4 border-t border-[#16181B]/10 flex items-center justify-between">
                  <span className="text-xs text-[#8E95A2]">
                    Medgón Passivhaus Editorial
                  </span>
                  <a
                    href={postLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs font-bold text-[#16181B] hover:text-[#0DA836] inline-flex items-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <span>Leer artículo completo</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                    <ExternalLink className="w-3 h-3 opacity-60" />
                  </a>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default BlogPosts;
