import { getAssetUrl } from '../utils/assetUrl';

export interface ModelData {
  id: string;
  name: string;
  code: string;
  m2Construidos: number;
  m2Utiles: number;
  bedrooms: number;
  bathrooms: number;
  plants: number;
  description: string;
  tagline: string;
  priceEstimateMin: number; // 1.700 €/m²
  priceEstimateMax: number; // 1.900 €/m²
  estimatedMonths: number;
  pdfPath?: string;
  floorplanPath: string;
  heroImage: string;
  galleryImages: { url: string; title: string; caption: string }[];
  style: string;
  customizableFeatures: string[];
  fixedTechnicalLimits: string[];
  aiRagSnippet: string;
  highlights: string[];
}

export const CATALOG_MODELS: Record<string, ModelData> = {
  'mg-87': {
    id: 'mg-87',
    name: 'MG 87 Tierra',
    code: 'MG 87',
    m2Construidos: 87.0,
    m2Utiles: 76.5,
    bedrooms: 2,
    bathrooms: 1,
    plants: 1,
    description: 'Compacta, eficiente y cálida. Ideal para 1 o 2 dormitorios con una distribución diáfana que aprovecha cada metro cuadrado.',
    tagline: 'Compacta, eficiente y cálida con distribución diáfana',
    priceEstimateMin: 147900,
    priceEstimateMax: 165300,
    estimatedMonths: 6,
    pdfPath: getAssetUrl('MG87/COMERCIAL - MG84 - V1 - Inclinada 30%.pdf'),
    floorplanPath: getAssetUrl('MG87/Mg_87_plano.jpg'),
    heroImage: getAssetUrl('MG87/castilian_wheat_house.jpg'),
    galleryImages: [
      { url: getAssetUrl('MG87/castilian_wheat_house.jpg'), title: 'Fachada Exterior', caption: 'Vivienda compacta Passivhaus integrada en el paisaje' },
      { url: getAssetUrl('MG87/castilian_wheat_stubble_house.jpg'), title: 'Fachada Lateral', caption: 'Porche exterior y grandes ventanales de captación solar' },
      { url: getAssetUrl('MG87/mediterranean_rustic_interior.jpg'), title: 'Salón Cálido', caption: 'Techos altos con vigas de madera vista y luz continua' },
      { url: getAssetUrl('MG87/cocina.jpg'), title: 'Cocina Integrada', caption: 'Distribución funcional conectada con la zona social' },
      { url: getAssetUrl('MG87/DOrmitorio.jpg'), title: 'Dormitorio Principal', caption: 'Confort acústico y aire filtrado 24h por VMC' },
      { url: getAssetUrl('MG87/Mg_87_plano.jpg'), title: 'Plano Técnico', caption: 'Distribución optimizada en planta única' },
    ],
    style: 'Rústico Castellano Cálido',
    customizableFeatures: [
      'Configuración de 1 suite amplia o 2 dormitorios independientes',
      'Integración opcional de porche exterior en madera',
      'Volteado en espejo completo para adaptación a la parcela',
      'Acabados interiores a elegir con gremios locales',
    ],
    fixedTechnicalLimits: [
      'Huecos y dimensiones de ventanas calibradas térmicamente',
      'Módulo húmedo de baños y cuarto de instalaciones VMC',
      'Estructura portante de madera técnica de alta precisión',
      'Membrana de estanqueidad al aire perimetral ininterrumpida',
    ],
    aiRagSnippet: 'Medgón MG 87 es una vivienda unifamiliar Passivhaus de 87 m² construidos con 1 o 2 dormitorios y 1 baño. Plazo cerrado de 6 meses y precio técnico de 1.700 a 1.900 €/m² + IVA.',
    highlights: ['Planta compacta 87 m²', '1 o 2 dormitorios', 'Cubierta inclinada 30%', 'Mínimo consumo energético'],
  },

  'mg-100': {
    id: 'mg-100',
    name: 'MG 100',
    code: 'MG 100',
    m2Construidos: 100.0,
    m2Utiles: 86.2,
    bedrooms: 3,
    bathrooms: 2,
    plants: 1,
    description: 'El equilibrio perfecto entre superficie habitable y eficiencia energética. Diseñada para familias que exigen 3 dormitorios en una sola planta con doble baño y amplia zona diáfana de día.',
    tagline: 'El equilibrio perfecto entre superficie habitable y eficiencia energética',
    priceEstimateMin: 170000,
    priceEstimateMax: 190000,
    estimatedMonths: 6,
    pdfPath: getAssetUrl('MG100/COMERCIAL - MG100 - V2 - Inclinada 30% cotas.pdf'),
    floorplanPath: getAssetUrl('MG100/MG_100_Plano.jpg'),
    heroImage: getAssetUrl('MG100/MG_100_Exterior.png'),
    galleryImages: [
      { url: getAssetUrl('MG100/MG_100_Exterior.png'), title: 'Fachada Principal', caption: 'Líneas limpias y carpintería de altas prestaciones' },
      { url: getAssetUrl('MG100/MG_100_exterior2.png'), title: 'Vista Posterior', caption: 'Conexión jardín y protección solar pasiva' },
      { url: getAssetUrl('MG100/MG_100_salon.png'), title: 'Salón Diáfano', caption: 'Salón con gran iluminación natural y confort térmico 21°C' },
      { url: getAssetUrl('MG100/MG_100_comedor.png'), title: 'Comedor Integrado', caption: 'Espacio social continuo con aire filtrado 24h por VMC' },
      { url: getAssetUrl('MG100/MG_100_cocina.png'), title: 'Cocina en Isla', caption: 'Zona de trabajo funcional adaptable a tu diseño preferido' },
      { url: getAssetUrl('MG100/MG_100_dormitorio.png'), title: 'Dormitorio Suite', caption: 'Suite con baño integrado y aislamiento acústico superior' },
      { url: getAssetUrl('MG100/MG_100_Plano.jpg'), title: 'Plano Acotado', caption: 'Plano comercial oficial con cotas y superficies útiles' },
    ],
    style: 'Arquitectura Nórdica Minimalista',
    customizableFeatures: [
      'Personalización completa de tabiquería interior de dormitorios y salón',
      'Giro y simetría en espejo para adaptación solar a la parcela',
      'Elección de acabados de suelos, alicatados e iluminación',
      'Integración opcional de porche exterior en madera',
    ],
    fixedTechnicalLimits: [
      'Huecos y dimensiones de ventanas calibradas térmicamente',
      'Módulo húmedo de baños y cuarto de instalaciones VMC',
      'Estructura portante de madera técnica de alta precisión',
      'Membrana de estanqueidad al aire perimetral ininterrumpida',
    ],
    aiRagSnippet: 'Medgón MG 100 es una vivienda unifamiliar Passivhaus de 100 m² construidos (86,2 m² útiles) con 3 dormitorios y 2 baños en planta baja. Coste técnico de 1.700 a 1.900 €/m² + IVA y entrega en 6 meses.',
    highlights: ['3 dormitorios en planta baja', 'Doble baño completo', 'Hermeticidad n50 ≤ 0.6', 'Ahorro energético del 85%'],
  },

  'mg-105': {
    id: 'mg-105',
    name: 'MG 105 Calzada',
    code: 'MG 105',
    m2Construidos: 105.0,
    m2Utiles: 105.0,
    bedrooms: 3,
    bathrooms: 2,
    plants: 1,
    description: 'Espacios fluidos orientados a captar la radiación solar invernal y disfrutar de ventilación continua saludable.',
    tagline: 'Espacios fluidos orientados a captar la radiación invernal y disfrutar de ventilación continua saludable',
    priceEstimateMin: 178500,
    priceEstimateMax: 199500,
    estimatedMonths: 6,
    pdfPath: getAssetUrl('MG105/MG 105.pdf'),
    floorplanPath: getAssetUrl('MG105/MG105 plano.jpg'),
    heroImage: getAssetUrl('MG105/industrial_luminous_house_exterior.jpg'),
    galleryImages: [
      { url: getAssetUrl('MG105/industrial_luminous_house_exterior.jpg'), title: 'Exterior Soleado', caption: 'Geometría serena con acabado exterior mineral y madera' },
      { url: getAssetUrl('MG105/sunny_industrial_garden_house.jpg'), title: 'Vista Jardín', caption: 'Integración paisajística con grandes ventanales de triple vidrio' },
      { url: getAssetUrl('MG105/industrial_living_room_sunlit.jpg'), title: 'Zona de Estar', caption: 'Luz natural continua y suelo radiante/refrescante invisible' },
      { url: getAssetUrl('MG105/industrial_dining_living_room.jpg'), title: 'Zona Comedor', caption: 'Volumen interior generoso con sensación de amplitud' },
      { url: getAssetUrl('MG105/industrial_bedroom_sunlit.jpg'), title: 'Dormitorio', caption: 'Descanso reparador con nivel de CO2 inferior a 800 ppm' },
      { url: getAssetUrl('MG105/MG105 plano.jpg'), title: 'Plano Técnico', caption: 'Planta de distribución con zonificación día/noche' },
    ],
    style: 'Espacios Fluidos & Radiación Invernal',
    customizableFeatures: [
      'Unión de dormitorios secundarios o conversión a despacho profesional',
      'Tabiquería divisoria de la zona social',
      'Orientación y orientación en espejo completa sobre la parcela',
      'Suelos, sanitarios y muebles de cocina contratados con gremios locales',
    ],
    fixedTechnicalLimits: [
      'Huecos y dimensiones de ventanas calibradas térmicamente',
      'Módulo húmedo de baños y cuarto de instalaciones',
      'Estructura portante de madera técnica de alta precisión',
      'Membrana de estanqueidad al aire perimetral ininterrumpida',
    ],
    aiRagSnippet: 'Medgón MG 105 Calzada es una vivienda de catálogo Passivhaus de 105 m² con 3 dormitorios y 2 baños. Fabricada en Carrión de los Condes en madera técnica, con entrega en 6 meses y coste técnico entre 1.700 y 1.900 €/m² + IVA.',
    highlights: ['Diseño luminoso continuo', 'Doble orientación solar', 'Aislamiento continuo sin puentes', 'Ahorro del 85% en climatización'],
  },

  'mg-128': {
    id: 'mg-128',
    name: 'MG 128 Equilibrio',
    code: 'MG 128',
    m2Construidos: 128.0,
    m2Utiles: 128.0,
    bedrooms: 3,
    bathrooms: 2,
    plants: 1,
    description: 'El modelo más demandado: tres dormitorios, dos baños completos y máxima estabilidad térmica anual.',
    tagline: 'El modelo más demandado: tres dormitorios, dos baños completos y máxima estabilidad térmica anual',
    priceEstimateMin: 217600,
    priceEstimateMax: 243200,
    estimatedMonths: 6,
    pdfPath: getAssetUrl('MG128/COMERCIAL - MG 128 - V2 - Cubierta plana.pdf'),
    floorplanPath: getAssetUrl('MG128/plano MG128.jpg'),
    heroImage: getAssetUrl('MG128/boho_autumn_exterior.jpg'),
    galleryImages: [
      { url: getAssetUrl('MG128/boho_autumn_exterior.jpg'), title: 'Fachada Otoñal', caption: 'Volumetría moderna con combinación de acabados naturales' },
      { url: getAssetUrl('MG128/autumn_boho_patio.jpg'), title: 'Patio y Porche', caption: 'Zona de transición exterior protegida del viento y del sol estival' },
      { url: getAssetUrl('MG128/boho_living_dining_room.jpg'), title: 'Salón Principal', caption: 'Techos amplios y confort acústico excepcional' },
      { url: getAssetUrl('MG128/boho_kitchen_warm.jpg'), title: 'Cocina Cálida', caption: 'Convivencia armónica entre madera y materiales minerales' },
      { url: getAssetUrl('MG128/boho_bedroom_warm.jpg'), title: 'Dormitorio Principal', caption: 'Privacidad absoluta con vistas controladas al jardín' },
      { url: getAssetUrl('MG128/plano MG128.jpg'), title: 'Plano Oficial', caption: 'Distribución funcional con separación clara de ambientes' },
    ],
    style: 'Modelo de Referencia Medgón',
    customizableFeatures: [
      'Opción de cubierta plana transitable/vegetal o cubierta inclinada tradicional',
      'Configuración de 3 dormitorios amplios o 4 dormitorios compactos',
      'Distribución de armarios empotrados y zonas de teletrabajo',
      'Volteado completo de planta según topografía del solar',
    ],
    fixedTechnicalLimits: [
      'Posición de los huecos exteriores de carpintería Passivhaus',
      'Núcleos de fontanería y baños para garantizar estanqueidad',
      'Cuarto técnico de VMC Zehnder ComfoAir y aerotermia',
      'Estructura exterior e interior portante en madera técnica',
    ],
    aiRagSnippet: 'Medgón MG 128 Equilibrio es una vivienda unifamiliar Passivhaus en madera técnica de 128 m² con 3 dormitorios y 2 baños. Ofrece certidumbre en 6 meses de obra y presupuesto técnico cerrado de 1.700 a 1.900 €/m² + IVA.',
    highlights: ['Cubierta plana o inclinada', 'Patio interior con luz natural', 'Certificación Passivhaus Classic', 'Confort térmico constante 20-22°C'],
  },

  'mg-148': {
    id: 'mg-148',
    name: 'MG 148 Villoldo',
    code: 'MG 148',
    m2Construidos: 148.0,
    m2Utiles: 148.0,
    bedrooms: 4,
    bathrooms: 3,
    plants: 2,
    description: 'Gran formato con suite principal independiente y menor repercusión fija de instalaciones por m².',
    tagline: 'Gran formato con suite principal independiente y menor repercusión fija de instalaciones por m²',
    priceEstimateMin: 251600,
    priceEstimateMax: 281200,
    estimatedMonths: 6,
    pdfPath: getAssetUrl('MG148/COMERCIAL - MG 148 - V1 - Cubierta inclinada.pdf'),
    floorplanPath: getAssetUrl('MG148/Plano MG148.jpg'),
    heroImage: getAssetUrl('MG148/l_shaped_farmhouse_golden_hour.jpg'),
    galleryImages: [
      { url: getAssetUrl('MG148/l_shaped_farmhouse_golden_hour.jpg'), title: 'Planta en L Atardecer', caption: 'Composición volumétrica en dos cuerpos que abraza la parcela' },
      { url: getAssetUrl('MG148/sunny_farmhouse_summer.jpg'), title: 'Exterior Estival', caption: 'Fachada continua con aislamiento térmico sin puentes' },
      { url: getAssetUrl('MG148/farmhouse_salon_comedor.jpg'), title: 'Salón de Gran Formato', caption: 'Espacio de reunión con conexión visual hacia el exterior' },
      { url: getAssetUrl('MG148/farmhouse_kitchen_rustic.jpg'), title: 'Cocina Familiar', caption: 'Amplitud para isla central y despensa' },
      { url: getAssetUrl('MG148/cozy_farmhouse_bedroom.jpg'), title: 'Dormitorio en Planta Alta', caption: 'Espacio abuhardillado con aislamiento de fibra de madera insuflada' },
      { url: getAssetUrl('MG148/Plano MG148.jpg'), title: 'Planta Baja y Alta', caption: 'Plano completo de las dos plantas con 4 dormitorios' },
    ],
    style: 'Gran Formato en L',
    customizableFeatures: [
      'Asignación de dormitorios (suite en planta baja o en planta superior)',
      'Espacio multifuncional en planta alta (estudio, biblioteca, sala de juegos)',
      'Volteado completo en L para amoldarse a los vientos dominantes',
      'Elección de puertas, parqués y acabados con gremios locales',
    ],
    fixedTechnicalLimits: [
      'Huecos exteriores de carpinterías y sellado de juntas de hermeticidad',
      'Ubicación de baños y patinillos de instalaciones verticales',
      'Cuarto técnico centralizado en planta baja para aerotermia y VMC',
      'Entramado portante de madera mecanizado en taller robotizado',
    ],
    aiRagSnippet: 'Medgón MG 148 es una vivienda unifamiliar Passivhaus de 148 m² en 2 plantas en L con 4 dormitorios y 3 baños. Precio técnico entre 1.700 y 1.900 €/m² + IVA, construida en madera técnica con plazo cerrado de 6 meses.',
    highlights: ['Diseño en L con patio protegido', 'Dormitorio suite en planta baja', '4 dormitorios y 3 baños', 'Test Blower Door garantizado'],
  },

  'mg-165': {
    id: 'mg-165',
    name: 'MG 165 Horizonte',
    code: 'MG 165',
    m2Construidos: 165.0,
    m2Utiles: 148.0,
    bedrooms: 4,
    bathrooms: 3,
    plants: 2,
    description: 'Vivienda unifamiliar de alta gama con 4 dormitorios, distribución en dos niveles y amplios porches integrados.',
    tagline: 'Vivienda unifamiliar de alta gama con distribución en dos niveles',
    priceEstimateMin: 280500,
    priceEstimateMax: 313500,
    estimatedMonths: 6,
    pdfPath: getAssetUrl('MG165/COMERCIAL - MG100 - V2 - Inclinada 30% cotas.pdf'),
    floorplanPath: getAssetUrl('MG165/coastal_l_shaped_home.jpg'),
    heroImage: getAssetUrl('MG165/coastal_sunset_house.jpg'),
    galleryImages: [
      { url: getAssetUrl('MG165/coastal_sunset_house.jpg'), title: 'Fachada Sunset', caption: 'Geometría depurada y presencia arquitectónica contemporánea' },
      { url: getAssetUrl('MG165/coastal_l_shaped_home.jpg'), title: 'Composición en Ángulo', caption: 'Apertura hacia el jardín y orientación pasiva' },
      { url: getAssetUrl('MG165/segovia_sunset_coastal.jpg'), title: 'Integración Paisajística', caption: 'Armonía con el entorno mediante materiales nobles' },
      { url: getAssetUrl('MG165/coastal_living_dining_room.jpg'), title: 'Zona de Estar y Comedor', caption: 'Amplitud espacial y temperatura homogénea todo el año' },
      { url: getAssetUrl('MG165/coastal_kitchen_sunset.jpg'), title: 'Cocina al Atardecer', caption: 'Diseño bioclimático con iluminación natural óptima' },
      { url: getAssetUrl('MG165/coastal_bedroom_morning.jpg'), title: 'Dormitorio Suite', caption: 'Máximo silencio y renovación continua de aire filtrado' },
    ],
    style: 'Alta Gama Contemporánea',
    customizableFeatures: [
      'Configuración de 4 a 5 dormitorios según necesidades familiares',
      'Integración de porche o pérgola bioclimática exterior',
      'Volteado en espejo completo adaptado al soleamiento de la parcela',
      'Elección personalizada de parqués, sanitarios y carpintería interior',
    ],
    fixedTechnicalLimits: [
      'Huecos y dimensiones de ventanas calibradas térmicamente',
      'Módulo húmedo de baños y cuarto de instalaciones centralizado',
      'Estructura portante de madera técnica de alta precisión',
      'Membrana de estanqueidad al aire perimetral ininterrumpida',
    ],
    aiRagSnippet: 'Medgón MG 165 es una vivienda de alta gama Passivhaus de 165 m² construidos con 4 a 5 dormitorios y 3 baños en dos plantas. Precio técnico entre 1.700 y 1.900 €/m² + IVA y entrega en 6 meses.',
    highlights: ['165 m² construidos en 2 plantas', '4-5 dormitorios y 3 baños', 'Amplios porches bioclimáticos', 'Certificación Passivhaus Classic'],
  },
};

export const ALL_MODELS_LIST = Object.values(CATALOG_MODELS);
