# ROLE & ARCHITECTURAL BRIEF
You are an expert Lead Front-End Engineer & CRO/SEO Architect.
Generate the production-ready code for "Medgón Passivhaus" (Spanish manufacturer of precision-engineered timber Passivhaus buildings based in Carrión de los Condes, Palencia).

The website is a Pure Static Multi-Page Application (MPA) hosted on a traditional Apache/Nginx web server under the `/app/` root path.
- Framework: Semantic HTML5 + Tailwind CSS + Vanilla JS (No Node/React runtime at deploy).
- Aesthetic: Inspired by Google Gemini / Ultra-clean SaaS UI (crisp mineral white background `#FAF8F5`, dark slate `#16181B` text, emerald `#0DA836` Passivhaus accent, glowing blue/purple aurora accents on key buttons, large border-radius `rounded-2xl` to `rounded-3xl`, soft drop-shadows, Bento Grid layout).
- Absolute Routing: All internal URLs MUST strictly begin with `/app/` (e.g., `/app/catalogo.html`, `/app/modelo-mg-87.html`).

---

## 1. DYNAMIC DATA STORE & SCALABILITY REQUIREMENT
To allow non-technical operators to add, remove, or replace housing models and blog posts without editing complex HTML blocks:
1. Provide an inline or external modular Vanilla JS data configuration object `window.MEDGON_DATA` containing:
   - `models`: Array of housing models (`id`, `code`, `builtM2`, `usefulM2`, `floors`, `beds`, `baths`, `priceFrom`, `popular`, `thumbUrl`, `slug`).
   - `blogPosts`: Array of the latest 4-6 articles (`id`, `title`, `category`, `readTime`, `date`, `snippet`, `thumbUrl`, `slug`).
2. The Home page horizontal models carousel and the Home page blog post slider MUST read from this data store and render clean, accessible Bento-style cards with scroll-snap.

---

## 2. STRICT IMAGE ASSET CONVENTION (WEBP & PLACEHOLDERS)
Organize all images cleanly into specific subfolders under `/app/images/`. Every `<img>` tag MUST have explicit `width`, `height`, `loading="lazy"` (except the Hero, which uses `loading="eager"`), descriptive Spanish SEO `alt` text, and use `https://placehold.co/` printing the exact folder path, filename, and recommended dimensions on the placeholder canvas:

- Global:
  - Logo: `https://placehold.co/180x50/FFFFFF/16181B.webp?text=/app/images/global/logo-medgon.webp+[180x50]`
- Home Hero:
  - Hero: `https://placehold.co/1200x800/FAF8F5/16181B.webp?text=/app/images/inicio/hero-portada.webp+[1200x800]`
- Models Catalog Cards (Horizontal Carousel):
  - MG 87: `https://placehold.co/800x550/F8FAFC/0DA836.webp?text=/app/images/modelos/mg-87/mg87-card.webp+[800x550]`
  - MG 100: `https://placehold.co/800x550/F8FAFC/2563EB.webp?text=/app/images/modelos/mg-100/mg100-card.webp+[800x550]`
  - MG 105: `https://placehold.co/800x550/F8FAFC/8B5CF6.webp?text=/app/images/modelos/mg-105/mg105-card.webp+[800x550]`
  - MG 128: `https://placehold.co/800x550/F8FAFC/EC4899.webp?text=/app/images/modelos/mg-128/mg128-card.webp+[800x550]`
  - MG 148: `https://placehold.co/800x550/F8FAFC/10B981.webp?text=/app/images/modelos/mg-148/mg148-card.webp+[800x550]`
  - MG 165: `https://placehold.co/800x550/F8FAFC/3B82F6.webp?text=/app/images/modelos/mg-165/mg165-card.webp+[800x550]`
- Blog Posts Thumbnails:
  - Post 1: `https://placehold.co/600x400/F1F5F9/16181B.webp?text=/app/images/blog/cuanto-cuesta-passivhaus.webp+[600x400]`
  - Post 2: `https://placehold.co/600x400/F1F5F9/16181B.webp?text=/app/images/blog/vmc-doble-flujo.webp+[600x400]`
  - Post 3: `https://placehold.co/600x400/F1F5F9/16181B.webp?text=/app/images/blog/claves-comprar-parcela.webp+[600x400]`
  - Post 4: `https://placehold.co/600x400/F1F5F9/16181B.webp?text=/app/images/blog/normativa-epbd-2030.webp+[600x400]`
- B2B Industrial Cards:
  - Fachadas: `https://placehold.co/1000x650/F1F5F9/16181B.webp?text=/app/images/b2b/fachadas-industrializadas.webp+[1000x650]`
  - Derecho de Vuelo: `https://placehold.co/1000x650/F1F5F9/16181B.webp?text=/app/images/b2b/remontas-altior.webp+[1000x650]`
  - Plurifamiliares: `https://placehold.co/1000x650/F1F5F9/16181B.webp?text=/app/images/b2b/edificios-altura.webp+[1000x650]`

---

## 3. HOMEPAGE (`/app/index.html`) STRUCTURE & FLOW

1. **Top Trust Bar**:
   - Concise items: Fábrica CNC en Carrión de los Condes (Palencia) · Marcado CE Kerto-Ripa · +200 Test Blower Door superados.
2. **Sticky Navigation Bar**:
   - Brand Logo on the left linking to `/app/index.html`.
   - Core Menu:
     - **Viviendas Passivhaus (B2C)**: Links to `/app/catalogo.html`, `/app/como-funciona.html`, `/app/nuestro-sistema.html`.
     - **Grandes Proyectos (B2B)**: Links to `/app/productos-fachadas.html`, `/app/productos-derecho-vuelo.html`, `/app/productos-plurifamiliares.html`, `/app/productos-terciario.html`.
     - **Proyectos Ejecutados**: Link to `/app/proyectos.html`.
     - **Blog**: Link to `/app/blog.html`.
   - Primary CTA Button: Aurora gradient `Estudiar mi parcela gratis →` linking to `/app/contacto.html`.
3. **Hero Section (B2C Punchy Hook)**:
   - Aurora badge: `✦ CATÁLOGO RESIDENCIAL INDUSTRIALIZADO 2026`
   - H1: `Tu casa Passivhaus de consumo casi nulo. Clara desde el inicio.`
   - Subtitle: Transparent pricing (1.700 – 1.900 €/m² + IVA) and delivery in ~6 months.
   - Interactive prompt bar (Gemini style): Floating card with prompt placeholder: `"¿Qué modelo encaja en mi terreno de 500 m² en Palencia o Cantabria?"` -> Button `Comprobar Viabilidad`.
   - Dual action CTAs: `[Ver Catálogo de Modelos]` and `[Tengo una parcela]`.
4. **Horizontal Models Carousel (Snap-Scroll)**:
   - Header with section title: `Modelos de Vivienda Industrializada` and Next/Prev control arrows.
   - Container with `overflow-x-auto snap-x snap-mandatory flex gap-6 scrollbar-none`.
   - Render models dynamically from `window.MEDGON_DATA.models` (MG-87, MG-100, MG-105, MG-128, MG-148, MG-165).
   - Each card displays surface, bedrooms, bathrooms, price estimate, key Passivhaus specs badge, and CTA `Ver planos y cotas →` pointing to `/app/modelo-[code].html`.
5. **Audience Bifurcation Module (B2C vs B2B in <2 seconds)**:
   - Split 2-column cards: Left for Autopromotores (Unifamiliares a precio cerrado) / Right for Constructoras, Promotores y Comunidades (Fachadas 2D, Remontas Altior, Plurifamiliares).
6. **Bento Grid: Certezas Técnicas y Financieras**:
   - 4-card asymmetric layout:
     - Card 1: Desglose Transparente (1.700 – 1.900 €/m²): Alcance técnico Medgón vs gremios locales.
     - Card 2: Montaje estructural en seco en 1-2 semanas.
     - Card 3: Salud y confort: VMC continuo con recuperación >90% y filtración F7/G4.
     - Card 4: Valor patrimonial: Cumplimiento de la Directiva Europea ZEB 2030.
7. **Latest Blog Articles (Horizontal Scrollable Grid)**:
   - Header: `Divulgación Técnica y Consejos para Autopromotores`.
   - Horizontal snap carousel featuring the latest 3-4 articles populated from `window.MEDGON_DATA.blogPosts`.
   - Card format: Category tag, read time, clear title, concise snippet, thumbnail WebP, and direct link to article or `/app/blog.html`.
8. **Interactive Land Viability Lead Magnet (Zero-Friction Form)**:
   - Fields: Nombre, Teléfono, Email, Localidad/Provincia de la parcela, Estado del terreno (Tengo parcela / Buscando / Sin terreno), Modelo de interés (Select dropdown populated with models).
   - Instant assurance note: `Estudio técnico preliminar 100% gratuito por ingenieros Passivhaus en 24-48h laborables.`
9. **Footer**:
   - Complete directory links to all 18 pages.
   - Local business information: Polígono Industrial, Nave 50, 34120 Carrión de los Condes (Palencia). Tel: 979 88 10 10.
   - Institutional links: Marcado CE Kerto-Ripa, Huella de Carbono ISO 14064 (MITECO), I+D+i.

---

## 4. DEDICATED MODEL TEMPLATE (`/app/modelo-mg-87.html`)
Provide the template for the individual model page adhering to SEO/AEO rules:
- Avoid repeating generic Passivhaus textbook definitions. Focus 80% on specific model data.
- H1: `MG 87 - 87 m² · Vivienda Passivhaus Medgón`
- Breadcrumb: `Inicio / Catálogo / MG 87 - 87 m²`
- Quick Specs Bar: 87 m² construidos | ~74,5 m² útiles | 1 Planta | 2-3 Dormitorios | 1-2 Baños | Inversión orientativa: 147.900 € – 165.300 € + IVA.
- Interactive Floor Plan Viewer: Tab toggle between "Plano de Distribución" (`mg87-plano-distribucion.webp`) and "Plano de Cotas y Medidas" (`mg87-plano-cotas.webp`).
- Customization Scope: Notice indicating bedrooms and living room sizes can be tailored, and orientation mirrored, while service shafts and envelope openings remain fixed to preserve closed pricing.
- Schema.org `SingleFamilyResidence` JSON-LD embedded.
- Pre-filled Viability Form with "MG 87" preselected.

---

## 5. TECHNICAL DELIVERABLE REQUIREMENTS
Output clean, production-ready, accessible, and responsive code:
1. Complete HTML5 document for `/app/index.html` with Tailwind CSS CDN script configured with Plus Jakarta Sans and custom Aurora gradients.
2. Lightweight Vanilla JS script managing the mobile menu, interactive prompt, smooth horizontal scroll controls, floorplan tabs, and dynamic rendering from `window.MEDGON_DATA`.
3. Complete JSON-LD schema for LocalBusiness/Organization (anchored to Carrión de los Condes, Palencia) and ItemList for models.