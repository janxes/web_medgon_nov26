/**
 * MEDGÓN PASSIVHAUS - SCRIPT PRINCIPAL
 * Interactividad: menú móvil, pestañas de planos y preselección de modelos.
 */
document.addEventListener('DOMContentLoaded', function () {
  // 1. Preseleccionar modelo en formulario de contacto desde parámetro URL
  var params = new URLSearchParams(window.location.search);
  var modeloParam = params.get('modelo');
  if (modeloParam) {
    var selectEl = document.getElementById('select-modelo');
    if (selectEl) {
      for (var i = 0; i < selectEl.options.length; i++) {
        if (selectEl.options[i].value.toLowerCase().includes(modeloParam.toLowerCase())) {
          selectEl.selectedIndex = i;
          break;
        }
      }
    }
  }

  // 2. Control de envío básico de formularios de contacto
  var form = document.getElementById('contact-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      alert('¡Gracias por tu solicitud! La oficina técnica de Medgón se pondrá en contacto contigo en un plazo máximo de 48 horas.');
    });
  }
});
