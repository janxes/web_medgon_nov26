/**
 * MEDGÓN PASSIVHAUS - CONFIGURACIÓN CENTRAL
 * ¡Tu "lista central" de imágenes y modelos!
 * Arquitectura estandarizada: rutas en minúsculas sin espacios ni caracteres especiales.
 */
window.MEDGON_CONFIG = {
  "company": {
    "name": "Medgón Passivhaus",
    "legalName": "Medgón Passivhaus S.L.",
    "location": "Carrión de los Condes (Palencia)",
    "foundedYear": 2005,
    "system": "Entramado ligero y contralaminado (CLT) de madera técnica robotizada",
    "pricePerM2Range": "1.700 €/m² – 1.900 €/m² + IVA",
    "manufacturingLeadTime": "4 a 6 meses de fabricación y montaje",
    "blowerDoorStandard": "n50 ≤ 0.6 ren/h (Ensayo Blower Door certificado obligatorio)",
    "phone": "+34 979 880 000",
    "email": "info@medgon.com"
  },
  "models": [
    {
      "id": "mg-87",
      "code": "MG 87",
      "name": "MG 87",
      "builtM2": 87,
      "usefulM2": 74.5,
      "floors": 1,
      "beds": "2 - 3",
      "baths": "1 - 2",
      "priceFrom": 156600,
      "priceTo": 174000,
      "popular": false,
      "tagline": "Compacta, eficiente y cálida con distribución diáfana optimizada",
      "style": "Rústico Castellano Cálido",
      "slug": "mg87.html",
      "aliasSlug": "modelo-mg-87.html",
      "thumbUrl": "assets/imagenes/mg87/exterior-1.webp",
      "planoDistribucion": "assets/imagenes/mg87/plano.webp",
      "planoCotas": "assets/imagenes/mg87/plano.webp",
      "gallery": [
        {
          "url": "assets/imagenes/mg87/exterior-1.webp",
          "title": "Fachada Principal",
          "caption": "Vivienda compacta Passivhaus integrada en el paisaje"
        },
        {
          "url": "assets/imagenes/mg87/exterior-2.webp",
          "title": "Fachada Lateral y Porche",
          "caption": "Porche exterior y grandes ventanales de captación solar"
        },
        {
          "url": "assets/imagenes/mg87/salon.webp",
          "title": "Salón Cálido",
          "caption": "Techos altos con vigas de madera vista y luz continua"
        },
        {
          "url": "assets/imagenes/mg87/cocina.webp",
          "title": "Cocina Integrada",
          "caption": "Distribución funcional conectada con la zona social"
        },
        {
          "url": "assets/imagenes/mg87/dormitorio.webp",
          "title": "Dormitorio Principal",
          "caption": "Confort acústico y aire filtrado 24h por VMC"
        },
        {
          "url": "assets/imagenes/mg87/plano.webp",
          "title": "Plano Técnico",
          "caption": "Distribución optimizada en planta única"
        }
      ],
      "highlights": [
        "Planta compacta 87 m²",
        "2-3 dormitorios",
        "Cubierta inclinada 30%",
        "Mínima huella de carbono"
      ],
      "description": "Compacta, eficiente y cálida. Ideal para 2 o 3 dormitorios con distribución diáfana que aprovecha cada metro cuadrado sin pérdidas energéticas."
    },
    {
      "id": "mg-100",
      "code": "MG 100",
      "name": "MG 100",
      "builtM2": 100,
      "usefulM2": 86.2,
      "floors": 1,
      "beds": "3",
      "baths": "2",
      "priceFrom": 180000,
      "priceTo": 200000,
      "popular": false,
      "tagline": "El equilibrio perfecto entre superficie habitable y eficiencia térmica",
      "style": "Arquitectura Nórdica Minimalista",
      "slug": "mg100.html",
      "aliasSlug": "modelo-mg-100.html",
      "thumbUrl": "assets/imagenes/mg100/exterior-1.webp",
      "planoDistribucion": "assets/imagenes/mg100/plano.webp",
      "planoCotas": "assets/imagenes/mg100/plano.webp",
      "pdfPath": "assets/imagenes/mg100/plano.pdf",
      "gallery": [
        {
          "url": "assets/imagenes/mg100/exterior-1.webp",
          "title": "Fachada Principal",
          "caption": "Líneas limpias contemporáneas y carpintería de triple vidrio Passivhaus"
        },
        {
          "url": "assets/imagenes/mg100/exterior-2.webp",
          "title": "Vista Posterior y Porche",
          "caption": "Conexión jardín con protección solar pasiva optimizada"
        },
        {
          "url": "assets/imagenes/mg100/salon.webp",
          "title": "Salón Diáfano",
          "caption": "Salón con gran iluminación natural y confort térmico 21°C continuo"
        },
        {
          "url": "assets/imagenes/mg100/comedor.webp",
          "title": "Comedor Integrado",
          "caption": "Espacio social continuo con aire filtrado 24h por sistema VMC"
        },
        {
          "url": "assets/imagenes/mg100/cocina.webp",
          "title": "Cocina en Isla",
          "caption": "Zona de trabajo funcional y ergonómica de diseño moderno"
        },
        {
          "url": "assets/imagenes/mg100/dormitorio.webp",
          "title": "Dormitorio Suite",
          "caption": "Suite principal con baño integrado y aislamiento acústico"
        }
      ],
      "highlights": [
        "3 dormitorios en planta baja",
        "Doble baño completo",
        "Hermeticidad n50 ≤ 0.6",
        "Ahorro térmico del 85%"
      ],
      "description": "Diseñada para familias que exigen 3 dormitorios en una sola planta con doble baño y amplia zona diáfana de día orientada al sol."
    },
    {
      "id": "mg-105",
      "code": "MG 105",
      "name": "MG 105",
      "builtM2": 105,
      "usefulM2": 105,
      "floors": 1,
      "beds": "3",
      "baths": "2",
      "priceFrom": 189000,
      "priceTo": 210000,
      "popular": false,
      "tagline": "Espacios fluidos orientados a captar la radiación solar pasiva",
      "style": "Espacios Fluidos & Radiación Invernal",
      "slug": "mg105.html",
      "aliasSlug": "modelo-mg-105.html",
      "thumbUrl": "assets/imagenes/mg105/exterior-1.webp",
      "planoDistribucion": "assets/imagenes/mg105/plano.webp",
      "planoCotas": "assets/imagenes/mg105/plano.webp",
      "gallery": [
        {
          "url": "assets/imagenes/mg105/exterior-1.webp",
          "title": "Fachada Exterior",
          "caption": "Diseño contemporáneo con amplios ventanales bioclimáticos"
        },
        {
          "url": "assets/imagenes/mg105/exterior-2.webp",
          "title": "Jardín y Entorno",
          "caption": "Integración natural con el terreno y protección solar"
        },
        {
          "url": "assets/imagenes/mg105/salon.webp",
          "title": "Salón Diáfano",
          "caption": "Espacio inundado de luz natural y máximo confort térmico"
        },
        {
          "url": "assets/imagenes/mg105/comedor.webp",
          "title": "Comedor",
          "caption": "Distribución abierta conectada con cocina y terraza"
        },
        {
          "url": "assets/imagenes/mg105/dormitorio.webp",
          "title": "Dormitorio Principal",
          "caption": "Ambiente silencioso y saludable con ventilación VMC continua"
        },
        {
          "url": "assets/imagenes/mg105/plano.webp",
          "title": "Planimetría Técnica",
          "caption": "Distribución técnica y zonificación Passivhaus"
        }
      ],
      "highlights": [
        "Diseño luminoso continuo",
        "Doble orientación solar",
        "Aislamiento continuo",
        "Ventilación VMC Zehnder"
      ],
      "description": "Espacios fluidos y amplias cristaleras de triple vidrio orientadas a captar la radiación solar invernal y disfrutar de ventilación continua saludable."
    },
    {
      "id": "mg-128",
      "code": "MG 128",
      "name": "MG 128",
      "builtM2": 128,
      "usefulM2": 128,
      "floors": 1,
      "beds": "3 - 4",
      "baths": "2",
      "priceFrom": 230400,
      "priceTo": 256000,
      "popular": true,
      "tagline": "El modelo de referencia más demandado: equilibrio y bioconfort",
      "style": "Modelo de Referencia Medgón",
      "slug": "mg128.html",
      "aliasSlug": "modelo-mg-128.html",
      "thumbUrl": "assets/imagenes/mg128/exterior-1.webp",
      "planoDistribucion": "assets/imagenes/mg128/plano.webp",
      "planoCotas": "assets/imagenes/mg128/plano.webp",
      "gallery": [
        {
          "url": "assets/imagenes/mg128/exterior-1.webp",
          "title": "Fachada Principal",
          "caption": "El equilibrio geométrico más galardonado de Medgón"
        },
        {
          "url": "assets/imagenes/mg128/exterior-2.webp",
          "title": "Patio Interior Bioclimático",
          "caption": "Eje de luz natural y ventilación cruzada controlada"
        },
        {
          "url": "assets/imagenes/mg128/salon.webp",
          "title": "Salón Abierto",
          "caption": "Confort térmico a 21°C garantizado en pleno invierno"
        },
        {
          "url": "assets/imagenes/mg128/cocina.webp",
          "title": "Cocina Integrada",
          "caption": "Mobiliario de diseño con isla central diáfana"
        },
        {
          "url": "assets/imagenes/mg128/dormitorio.webp",
          "title": "Dormitorio Principal",
          "caption": "Dormitorio de alta prestación acústica y térmica"
        },
        {
          "url": "assets/imagenes/mg128/plano.webp",
          "title": "Planimetría Técnica",
          "caption": "Cotas y superficies útiles oficiales"
        }
      ],
      "highlights": [
        "Cubierta plana o inclinada",
        "Patio de luz bioclimático",
        "Certificación Classic",
        "Temperatura estable 21°C"
      ],
      "description": "El modelo estrella de catálogo: 3 dormitorios amplios, patio interior de luz y máxima estabilidad de temperatura en verano e invierno."
    },
    {
      "id": "mg-148",
      "code": "MG 148",
      "name": "MG 148",
      "builtM2": 148,
      "usefulM2": 148,
      "floors": 2,
      "beds": "4",
      "baths": "3",
      "priceFrom": 266400,
      "priceTo": 296000,
      "popular": false,
      "tagline": "Gran formato en L con suite principal independiente en planta baja",
      "style": "Gran Formato en L",
      "slug": "mg148.html",
      "aliasSlug": "modelo-mg-148.html",
      "thumbUrl": "assets/imagenes/mg148/exterior-1.webp",
      "planoDistribucion": "assets/imagenes/mg148/plano.webp",
      "planoCotas": "assets/imagenes/mg148/plano.webp",
      "gallery": [
        {
          "url": "assets/imagenes/mg148/exterior-1.webp",
          "title": "Fachada en L",
          "caption": "Geometría envolvente que abraza el jardín y protege del viento"
        },
        {
          "url": "assets/imagenes/mg148/exterior-2.webp",
          "title": "Porche y Piscina",
          "caption": "Zona de ocio exterior conectada al salón principal"
        },
        {
          "url": "assets/imagenes/mg148/salon.webp",
          "title": "Salón a Doble Altura",
          "caption": "Sensación de amplitud con gran presencia de madera vista"
        },
        {
          "url": "assets/imagenes/mg148/cocina.webp",
          "title": "Cocina y Despensa",
          "caption": "Espacio culinario amplio para grandes reuniones familiares"
        },
        {
          "url": "assets/imagenes/mg148/dormitorio.webp",
          "title": "Suite en Planta Baja",
          "caption": "Independencia total con vestidor y baño privado completo"
        },
        {
          "url": "assets/imagenes/mg148/plano.webp",
          "title": "Planimetría Técnica en L",
          "caption": "Distribución en dos plantas con zonas de día y noche"
        }
      ],
      "highlights": [
        "Diseño en L envolvente",
        "Suite en planta baja",
        "4 dormitorios y 3 baños",
        "Blower Door n50 ≤ 0.5"
      ],
      "description": "Composición volumétrica en dos cuerpos que abraza el jardín y protege del viento norte, con dormitorio suite en planta baja."
    },
    {
      "id": "mg-165",
      "code": "MG 165",
      "name": "MG 165",
      "builtM2": 165,
      "usefulM2": 148,
      "floors": 2,
      "beds": "4 - 5",
      "baths": "3",
      "priceFrom": 297000,
      "priceTo": 330000,
      "popular": false,
      "tagline": "Alta gama contemporánea con porches bioclimáticos integrados",
      "style": "Alta Gama Contemporánea",
      "slug": "mg165.html",
      "aliasSlug": "modelo-mg-165.html",
      "thumbUrl": "assets/imagenes/mg165/exterior-1.webp",
      "planoDistribucion": "assets/imagenes/mg165/plano.webp",
      "planoCotas": "assets/imagenes/mg165/plano.webp",
      "gallery": [
        {
          "url": "assets/imagenes/mg165/exterior-1.webp",
          "title": "Fachada Representativa",
          "caption": "Máxima prestancia arquitectónica con volúmenes compensados"
        },
        {
          "url": "assets/imagenes/mg165/exterior-2.webp",
          "title": "Porches Volados",
          "caption": "Sombreado pasivo óptimo para máxima eficiencia estacional"
        },
        {
          "url": "assets/imagenes/mg165/salon.webp",
          "title": "Gran Salón Social",
          "caption": "Conexión visual continua jardín-interior"
        },
        {
          "url": "assets/imagenes/mg165/cocina.webp",
          "title": "Cocina de Alta Gama",
          "caption": "Equipamiento premium con acabados sostenibles"
        },
        {
          "url": "assets/imagenes/mg165/dormitorio.webp",
          "title": "Master Suite Superior",
          "caption": "Terraza privada con vistas y aislamiento acústico total"
        },
        {
          "url": "assets/imagenes/mg165/plano.webp",
          "title": "Planimetría Técnica 165 m²",
          "caption": "Diseño integral en 2 niveles"
        }
      ],
      "highlights": [
        "165 m² en dos niveles",
        "4-5 dormitorios",
        "Porches bioclimáticos",
        "Eficiencia A+ ZEB"
      ],
      "description": "Vivienda unifamiliar de alta gama con distribución en dos niveles, amplios porches bioclimáticos y máxima prestancia arquitectónica."
    }
  ],
  "blogPosts": [
    {
      "id": "coste-passivhaus",
      "title": "¿Cuánto cuesta realmente una casa Passivhaus en España en 2026?",
      "category": "Economía & Costes",
      "readTime": "4 min de lectura",
      "date": "15 de Mayo, 2026",
      "snippet": "Desglose transparente de costes por m²: qué incluye la fase técnica de fábrica frente a la obra tradicional y por qué amortizas la inversión en 7 años.",
      "thumbUrl": "assets/imagenes/generales/marratxi.webp",
      "slug": "blog.html#coste-passivhaus"
    },
    {
      "id": "vmc-doble-flujo",
      "title": "VMC de doble flujo: aire 100% puro sin abrir ventanas ni perder calor",
      "category": "Salud & Confort",
      "readTime": "5 min de lectura",
      "date": "28 de Abril, 2026",
      "snippet": "La ventilación mecánica controlada renueva el aire cada 2 horas, reteniendo polen y ácaros con filtros F7 y manteniendo CO2 por debajo de 800 ppm.",
      "thumbUrl": "assets/imagenes/generales/hero.webp",
      "slug": "blog.html#vmc-doble-flujo"
    },
    {
      "id": "comprar-parcela",
      "title": "5 claves técnicas antes de comprar una parcela para tu casa industrializada",
      "category": "Guía Autopromotor",
      "readTime": "6 min de lectura",
      "date": "10 de Abril, 2026",
      "snippet": "Cómo evaluar la orientación solar, la pendiente topográfica y los accesos para camión góndola antes de firmar las arras del terreno.",
      "thumbUrl": "assets/imagenes/generales/waldorf.webp",
      "slug": "blog.html#comprar-parcela"
    },
    {
      "id": "normativa-epbd-2030",
      "title": "Directiva Europea EPBD 2028-2030: el fin de la obra convencional obsoleta",
      "category": "Normativa & ZEB",
      "readTime": "5 min de lectura",
      "date": "22 de Marzo, 2026",
      "snippet": "La normativa europea prohibirá emisiones directas en obra nueva. La madera técnica ya supera con holgura los estándares de ciclo de vida ZEB.",
      "thumbUrl": "assets/imagenes/generales/plurifamiliar.webp",
      "slug": "blog.html#normativa-epbd-2030"
    }
  ]
};
